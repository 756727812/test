export default function (array) {
  return array.length === 1 ? array[0] : array.join(' ')
}
