## 引入

``` js
import DevicePlugin from 'vux/src/plugins/device'
Vue.use(DevicePlugin)
```

``` js
this.$device.isAndroid
this.$device.isIpad
this.$device.isIpod
this.$device.isIphone
this.$device.isWechat
this.$device.isAlipay
```
