<script>
import base from './mixin'

export default {
  mixins: [base],
  data () {
    return {
      chartName: 'area'
    }
  }
}
</script>
