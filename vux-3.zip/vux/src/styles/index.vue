<style lang="less">
/** this component is used only for building vux.css **/
@import './index.less';
</style>